

Quick build:

g++ src/fm_radio.cpp src/audio.cpp src/main.cpp -o fm_radio -Wno-narrowing
./fm_radio test/usrp.dat